import React from 'react';

function About(props) {
    return (
        <div>
            <h1>About</h1>
        </div>
    );
}

export default About;